<div class="list-item-privacy list-item-image-tools --top --left">
    <div class="btn-lock fas fa-eye-slash"></div>
</div>