<?php

if (!defined('access') or !access) {
    die('This file cannot be directly accessed.');
}
?>
<?php /* Code you add in this file will be added after </head>. See: app/themes/Peafowl/head.php */ ?>
