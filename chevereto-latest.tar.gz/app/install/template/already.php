<?php if(!defined('access') or !access) die('This file cannot be directly accessed.'); ?>
<h1><?php _se('Already installed'); ?></h1>
<p><?php _se('Chevereto is already installed and updated.'); ?></p>
<div class="btn-container margin-bottom-0"><a href="<?php echo G\get_base_url('dashboard'); ?>" class="btn btn-input default"><?php _se('Dashboard'); ?></a></div>